package com.farhandevops.skyway.services;
import android.content.Context;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.farhandevops.skyway.models.Flights;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class TicketGenerationService {
    private Context context;

    // Constructor to pass context
    public TicketGenerationService(Context context) {
        this.context = context;
    }

    public File generateTicketPDF(
            Flights flight,
            String passengerName,
            String email,
            String bookingDate,
            String transactionId
    ) {
        File pdfFile = null;
        try {
            // Create file in app's external files directory
            pdfFile = new File(
                    context.getExternalFilesDir(null),
                    "flight_ticket_" + transactionId + ".pdf"
            );

            // Ensure the file can be created
            if (!pdfFile.exists()) {
                pdfFile.createNewFile();
            }

            // Create PDF writer
            PdfWriter writer = new PdfWriter(new FileOutputStream(pdfFile));
            PdfDocument pdfDocument = new PdfDocument(writer);
            Document document = new Document(pdfDocument);

            // Ticket Design
            document.add(new Paragraph("SkyWay Airlines - Flight Ticket")
                    .setFontSize(24)
                    .setBold());

            // Create a table for ticket details
            Table ticketDetails = new Table(2);

            // Add ticket information
            addTableRow(ticketDetails, "Passenger Name", passengerName);
            addTableRow(ticketDetails, "Flight Number", flight.getFlightNumber());
            addTableRow(ticketDetails, "Departure", flight.getDepartureCity());
            addTableRow(ticketDetails, "Arrival", flight.getArrivalCity());
            addTableRow(ticketDetails, "Departure Time", flight.getDepartureTime());
            addTableRow(ticketDetails, "Transaction ID", transactionId);
            addTableRow(ticketDetails, "Booking Date", bookingDate);

            document.add(ticketDetails);

            // Close the document
            document.close();

            return pdfFile;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Helper method to add rows to the table
    private void addTableRow(Table table, String label, String value) {
        table.addCell(label);
        table.addCell(value);
    }

    // Static method to create an instance with context
    public static TicketGenerationService getInstance(Context context) {
        return new TicketGenerationService(context);
    }
}