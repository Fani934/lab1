package com.farhandevops.skyway.services;
import com.farhandevops.skyway.models.Flight;
import com.farhandevops.skyway.models.Flights;
import com.farhandevops.skyway.models.Ticket;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class ReportGenerator {

    // Generate a CSV report for booked tickets
    public void generateTicketReport(List<Ticket<?>> tickets, String filePath) throws IOException {
        try (FileWriter writer = new FileWriter(filePath)) {
            writer.append("Ticket ID,Flight ID,Customer Name,Email,Phone,Price\n");
            for (Ticket<?> ticket : tickets) {
                writer.append(ticket.getTicketId()).append(",")
                        .append(ticket.getFlightId()).append(",")
                        .append(ticket.getPassengerInfo().toString()).append(",")
                        .append(String.valueOf(ticket.getPrice())).append("\n");
            }
            System.out.println("Ticket report generated successfully at: " + filePath);
        }
    }

    // Generate a CSV report for flight details
    public void generateFlightReport(List<Flights> flights, String filePath) throws IOException {
        try (FileWriter writer = new FileWriter(filePath)) {
            writer.append("Flight ID,Origin,Destination,Departure Time,Arrival Time,Available Seats\n");
            for (Flights flight : flights) {
                writer.append(flight.getFlightId()).append(",")
                        .append(flight.getOrigin()).append(",")
                        .append(flight.getDestination()).append(",")
                        .append(flight.getDepartureTime().toString()).append(",")
                        .append(flight.getArrivalTime().toString()).append(",")
                        .append(String.valueOf(flight.getTotalSeats())).append("\n");
            }
            System.out.println("Flight report generated successfully at: " + filePath);
        }
    }
}