package com.farhandevops.skyway;

import android.app.DatePickerDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.layout.properties.UnitValue;
import com.itextpdf.layout.properties.TextAlignment;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.Random;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class BookFlightActivity extends AppCompatActivity {

    private EditText nameInput, emailInput, passengersInput;
    private AutoCompleteTextView fromInput, toInput;
    private Button dateButton, bookButton;
    private Spinner passengerTypeSpinner;
    private Calendar calendar;
    private String selectedDate;

    private static String flightTime;
    private static String gateNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_flight);

        nameInput = findViewById(R.id.name_input);
        emailInput = findViewById(R.id.email_input);
        fromInput = findViewById(R.id.from_input);
        toInput = findViewById(R.id.to_input);
        passengersInput = findViewById(R.id.passengers_input);
        dateButton = findViewById(R.id.date_button);
        bookButton = findViewById(R.id.book_button);
        passengerTypeSpinner = findViewById(R.id.passenger_type_spinner);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.passenger_types, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        passengerTypeSpinner.setAdapter(adapter);

        calendar = Calendar.getInstance();
        dateButton.setOnClickListener(v -> showDatePicker());
        bookButton.setOnClickListener(v -> bookFlight());
    }

    private void showDatePicker() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view, year, month, dayOfMonth) -> {
                    selectedDate = dayOfMonth + "/" + (month + 1) + "/" + year;
                    dateButton.setText(selectedDate);
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
    }

    private void bookFlight() {
        String name = nameInput.getText().toString().trim();
        String email = emailInput.getText().toString().trim();
        String from = fromInput.getText().toString().trim();
        String to = toInput.getText().toString().trim();
        String passengers = passengersInput.getText().toString().trim();
        String passengerType = passengerTypeSpinner.getSelectedItem().toString();

        if (name.isEmpty() || email.isEmpty() || from.isEmpty() || to.isEmpty() || passengers.isEmpty() || selectedDate == null) {
            Toast.makeText(this, "Please fill all the fields", Toast.LENGTH_SHORT).show();
            return;
        }

        flightTime = generateRandomFlightTime();
        gateNo = generateRandomGateNo();

        File pdfFile = generatePdfTicket(name, email, from, to, selectedDate, passengers, passengerType, flightTime, gateNo);
        if (pdfFile != null) {
            new SendEmailTask(this).execute(name, email, from, to, selectedDate, passengers, passengerType, pdfFile.getAbsolutePath());
        } else {
            Toast.makeText(this, "Failed to generate ticket", Toast.LENGTH_SHORT).show();
        }
    }

    private String generateRandomFlightTime() {
        Random rand = new Random();
        int hour = rand.nextInt(12) + 1; // Random hour between 1 and 12
        int minute = rand.nextInt(60);  // Random minute
        String amPm = (rand.nextInt(2) == 0) ? "AM" : "PM"; // Randomly choose AM or PM
        return String.format("%02d:%02d %s", hour, minute, amPm);
    }

    private String generateRandomGateNo() {
        Random rand = new Random();
        int gate = rand.nextInt(50) + 1; // Random gate number between 1 and 50
        return "Gate " + gate;
    }

    private File generatePdfTicket(String name, String email, String from, String to, String date, String passengers, String passengerType, String flightTime, String gateNo) {
        File pdfFile = new File(getExternalFilesDir(null), "SkywayTicket.pdf");

        try {
            PdfWriter writer = new PdfWriter(new FileOutputStream(pdfFile));
            PdfDocument pdfDocument = new PdfDocument(writer);
            Document document = new Document(pdfDocument);

            Drawable logoDrawable = getResources().getDrawable(R.drawable.logo2, null);
            Bitmap bitmap = drawableToBitmap(logoDrawable);
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
            byte[] bitmapData = stream.toByteArray();
            Image logoImage = new Image(ImageDataFactory.create(bitmapData));
            logoImage.setWidth(150);
            logoImage.setHeight(50);
            logoImage.setAutoScale(true);
            document.add(logoImage);

            document.add(new Paragraph("Skyway Airlines Flight Ticket")
                    .setFontSize(16)
                    .setBold()
                    .setTextAlignment(TextAlignment.CENTER)
                    .setMarginTop(10));

            Table table = new Table(UnitValue.createPercentArray(new float[]{2, 8}))
                    .useAllAvailableWidth();
            table.addCell("Name:");
            table.addCell(name);
            table.addCell("Email:");
            table.addCell(email);
            table.addCell("From:");
            table.addCell(from);
            table.addCell("To:");
            table.addCell(to);
            table.addCell("Date:");
            table.addCell(date);
            table.addCell("Flight Time:");
            table.addCell(flightTime);
            table.addCell("Gate No:");
            table.addCell(gateNo);
            table.addCell("Passengers:");
            table.addCell(passengers);
            table.addCell("Passenger Type:");
            table.addCell(passengerType);

            document.add(table);

            // General Instructions section
            document.add(new Paragraph("General Instructions:")
                    .setFontSize(12)
                    .setBold()
                    .setTextAlignment(TextAlignment.LEFT)
                    .setMarginTop(10));
            document.add(new Paragraph("1. Please arrive at the airport at least 2 hours before your flight departure.")
                    .setFontSize(10)
                    .setTextAlignment(TextAlignment.LEFT));
            document.add(new Paragraph("2. Make sure to carry a valid ID and your booking confirmation for check-in.")
                    .setFontSize(10)
                    .setTextAlignment(TextAlignment.LEFT));
            document.add(new Paragraph("3. Flight schedules are subject to change. Keep checking for updates.")
                    .setFontSize(10)
                    .setTextAlignment(TextAlignment.LEFT));
            document.add(new Paragraph("4. If you need assistance, contact Skyway Airlines customer service.")
                    .setFontSize(10)
                    .setTextAlignment(TextAlignment.LEFT));

            document.add(new Paragraph("Skyway Airlines\nContact: skywayairlines247@gmail.com\nPhone: +1-800-123-4567")
                    .setFontSize(8)
                    .setTextAlignment(TextAlignment.CENTER)
                    .setMarginTop(20));

            document.close();
            return pdfFile;

        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private Bitmap drawableToBitmap(Drawable drawable) {
        if (drawable instanceof BitmapDrawable) {
            return ((BitmapDrawable) drawable).getBitmap();
        }

        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);

        return bitmap;
    }

    private static class SendEmailTask extends AsyncTask<String, Void, Boolean> {
        private Context context;

        public SendEmailTask(Context context) {
            this.context = context;
        }

        @Override
        protected Boolean doInBackground(String... params) {
            String name = params[0];
            String recipientEmail = params[1];
            String from = params[2];
            String to = params[3];
            String date = params[4];
            String passengers = params[5];
            String passengerType = params[6];
            String filePath = params[7];

            final String username = "skywayairlines247@gmail.com"; // Your Gmail address
            final String password = "xladzztksxubypmb"; // Your App Password

            Properties props = new Properties();
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host", "smtp.gmail.com");
            props.put("mail.smtp.port", "587");

            Session session = Session.getInstance(props, new javax.mail.Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(username, password);
                }
            });

            try {
                Message message = new MimeMessage(session);
                message.setFrom(new InternetAddress(username));
                message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));
                message.setSubject("Your Skyway Airlines Flight Ticket");

                String htmlMessage = "<html>" +
                        "<body>" +
                        "<h2>Dear " + name + ",</h2>" +
                        "<p>Thank you for booking your flight with Skyway Airlines. Please find your flight ticket attached to this email.</p>" +
                        "<p><strong>Flight Details:</strong></p>" +
                        "<ul>" +
                        "<li><strong>From:</strong> " + from + "</li>" +
                        "<li><strong>To:</strong> " + to + "</li>" +
                        "<li><strong>Date:</strong> " + date + "</li>" +
                        "<li><strong>Flight Time:</strong> " + flightTime + "</li>" +
                        "<li><strong>Gate No:</strong> " + gateNo + "</li>" +
                        "<li><strong>Number of Passengers:</strong> " + passengers + "</li>" +
                        "<li><strong>Passenger Type:</strong> " + passengerType + "</li>" +
                        "</ul>" +
                        "<p>We look forward to serving you onboard.</p>" +
                        "<p>Sincerely,<br>Skyway Airlines</p>" +
                        "</body>" +
                        "</html>";

                message.setContent(htmlMessage, "text/html");

                javax.mail.BodyPart attachmentPart = new javax.mail.internet.MimeBodyPart();
                ((MimeBodyPart) attachmentPart).attachFile(filePath);

                javax.mail.Multipart multipart = new javax.mail.internet.MimeMultipart();
                multipart.addBodyPart(attachmentPart);

                message.setContent(multipart);

                Transport.send(message);

                return true;
            } catch (MessagingException | IOException e) {
                e.printStackTrace();
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean result) {
            if (result) {
                Toast.makeText(context, "Ticket sent to your email", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, "Failed to send email", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
