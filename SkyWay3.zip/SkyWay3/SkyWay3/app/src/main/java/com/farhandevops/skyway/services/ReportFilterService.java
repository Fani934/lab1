package com.farhandevops.skyway.services;
import com.farhandevops.skyway.models.Flights;
import com.farhandevops.skyway.models.Ticket;

import java.util.List;
import java.util.stream.Collectors;

public class ReportFilterService {

    // Search tickets by customer name or flight ID
    public List<Ticket<?>> searchTickets(List<Ticket<?>> tickets, String keyword) {
        return tickets.stream()
                .filter(ticket -> ticket.getFlightId().contains(keyword) ||
                        ticket.getPassengerInfo().toString().contains(keyword))
                .collect(Collectors.toList());
    }

    // Search flights by origin, destination, or flight ID
    public List<Flights> searchFlights(List<Flights> flights, String keyword) {
        return flights.stream()
                .filter(flight -> flight.getFlightId().contains(keyword) ||
                        flight.getOrigin().contains(keyword) ||
                        flight.getDestination().contains(keyword))
                .collect(Collectors.toList());
    }
}