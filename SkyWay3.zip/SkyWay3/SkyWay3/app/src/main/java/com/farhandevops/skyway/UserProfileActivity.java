package com.farhandevops.skyway;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.farhandevops.skyway.services.UserProfileService;

public class UserProfileActivity extends AppCompatActivity {

    private EditText nameInput, emailInput;
    private Button saveButton;
    private TextView profileInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        nameInput = findViewById(R.id.name_input);
        emailInput = findViewById(R.id.email_input);
        saveButton = findViewById(R.id.save_button);
        profileInfo = findViewById(R.id.profile_info);

        // Promo banner setup
        TextView promoBanner = findViewById(R.id.promo_banner);
        promoBanner.setText("Update Your Profile");

        // Display saved profile info
        String savedProfile = UserProfileService.getUserProfile(UserProfileActivity.this);
        profileInfo.setText(savedProfile);

        saveButton.setOnClickListener(v -> {
            String name = nameInput.getText().toString();
            String email = emailInput.getText().toString();

            if (name.isEmpty() || email.isEmpty()) {
                Toast.makeText(UserProfileActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else {
                // Save the profile
                UserProfileService.saveUserProfile(UserProfileActivity.this, name, email);
                profileInfo.setText("Name: " + name + "\nEmail: " + email); // Update UI
            }
        });
    }
}
