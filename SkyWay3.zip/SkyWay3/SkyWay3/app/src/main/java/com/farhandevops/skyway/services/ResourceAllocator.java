package com.farhandevops.skyway.services;
public class ResourceAllocator {
    private final Object Lock1 = new Object();
    private final Object Lock2 = new Object();
    // Thread 1 tries to acquire Lock1 first, then Lock2
    public void method1() {
        synchronized (Lock1) { // Lock1 acquire karna (Pehle Lock1 acquire karta hai)
            System.out.println("Thread 1: Holding Lock1...");
            try {
                Thread.sleep(100); // Sleep karte hue (Simulate delay)
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            synchronized (Lock2) { // Phir Lock2 acquire karna (Then tries to acquire Lock2)
                System.out.println("Thread 1: Acquired Lock2!");
            }
        }
    }
    // Thread 2 tries to acquire Lock2 first, then Lock1
    public void method2() {
        synchronized (Lock2) { // Lock2 acquire karna (Pehle Lock2 acquire karta hai)
            System.out.println("Thread 2: Holding Lock2...");
            try {
                Thread.sleep(100); // Sleep karte hue (Simulate delay)
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            synchronized (Lock1) { // Phir Lock1 acquire karna (Then tries to acquire Lock1)
                System.out.println("Thread 2: Acquired Lock1!");
            }
        }
    }

    // Avoid Deadlock by acquiring locks in a consistent order
    public void resolveDeadlock() {
        synchronized (Lock1) { // Consistent order mein locks acquire karna (Acquire locks in the same order)
            synchronized (Lock2) {
                System.out.println("Resolved deadlock by acquiring locks in a consistent order.");
            }
        }
    }
}
