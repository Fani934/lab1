package com.farhandevops.skyway.tests;

import static org.junit.jupiter.api.Assertions.*;

import com.farhandevops.skyway.models.Customer;
import com.farhandevops.skyway.models.Flights;
import com.farhandevops.skyway.models.Ticket;
import com.farhandevops.skyway.services.BookingService;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

public class BookingServiceTest {

    private static final UUID UUID = java.util.UUID.randomUUID(); // Initialize UUID here

    @Test
    public void testSuccessfulBooking() throws Exception {
        // Create a test flight
        Flights flight = new Flights.Builder()
                .setFlightId("FL123")
                .setOrigin("New York")
                .setDestination("Los Angeles")
                .setDepartureTime(String.valueOf(LocalDateTime.now().plusHours(3)))
                .setArrivalTime(String.valueOf(LocalDateTime.now().plusHours(6)))
                .setTotalSeats(5)
                .build();

        List<Flights> flights = Arrays.asList(flight);

        // Initialize BookingService
        BookingService bookingService = new BookingService(flights);

        // Create a test customer
        Customer customer = new Customer.Builder()
                .setCustomerId("C001")
                .setName("Farhan Mehmood")
                .setEmail("farhanmehmood043@gmail.com")
                .setPhone("1234567890")
                .build();

        // Book a ticket
        Ticket<Customer> ticket = bookingService.bookTicket("FL123", customer, 299.99);

        // Assertions
        assertNotNull(ticket);
        assertEquals("FL123", ticket.getFlightId());
        assertEquals(customer, ticket.getPassengerInfo());
        assertEquals(299.99, ticket.getPrice());
        assertEquals(4, bookingService.getAvailableSeats("FL123")); // Check remaining seats
    }

    @Test
    public void testOverbooking() {
        // Create a test flight with only 1 seat
        Flights flight = new Flights.Builder()
                .setFlightId("FL456")
                .setOrigin("London")
                .setDestination("Paris")
                .setDepartureTime(String.valueOf(LocalDateTime.now().plusHours(2)))
                .setArrivalTime(String.valueOf(LocalDateTime.now().plusHours(4)))
                .setTotalSeats(1)
                .build();

        List<Flights> flights = Arrays.asList(flight);

        // Initialize BookingService
        BookingService bookingService = new BookingService(flights);

        // Create two test customers
        Customer customer1 = new Customer.Builder()
                .setCustomerId("C002")
                .setName("Alice Smith")
                .setEmail("alicesmith222@gmail.com")
                .setPhone("9876543210")
                .build();

        Customer customer2 = new Customer.Builder()
                .setCustomerId("C003")
                .setName("Abdullah Khan")
                .setEmail("abdullahkhan50@gmail.com")
                .setPhone("1112223334")
                .build();

        // Book a ticket for the first customer
        assertDoesNotThrow(() -> bookingService.bookTicket("FL456", customer1, 199.99));

        // Attempt to overbook for the second customer
        Exception exception = assertThrows(Exception.class, () -> bookingService.bookTicket("FL456", customer2, 199.99));
        assertEquals("No available seats for flight: FL456", exception.getMessage());
    }

    @Test
    public void testThreadSafety() throws Exception {
        // Create a test flight with multiple seats
        Flights flight = new Flights.Builder()
                .setFlightId("FL789")
                .setOrigin("Tokyo")
                .setDestination("Osaka")
                .setDepartureTime(String.valueOf(LocalDateTime.now().plusHours(1)))
                .setArrivalTime(String.valueOf(LocalDateTime.now().plusHours(2)))
                .setTotalSeats(100)
                .build();

        List<Flights> flights = Arrays.asList(flight);

        // Initialize BookingService
        BookingService bookingService = new BookingService(flights);

        // Create a Runnable task for booking tickets
        Runnable bookingTask = () -> {
            try {
                Customer customer = new Customer.Builder()
                        .setCustomerId(UUID.randomUUID().toString())
                        .setName("Test User")
                        .setEmail("test.user@example.com")
                        .setPhone("1234567890")
                        .build();

                bookingService.bookTicket("FL789", customer, 99.99);
            } catch (Exception e) {
                e.printStackTrace();
            }
        };

        // Start multiple threads
        Thread thread1 = new Thread(bookingTask);
        Thread thread2 = new Thread(bookingTask);
        Thread thread3 = new Thread(bookingTask);

        thread1.start();
        thread2.start();
        thread3.start();

        thread1.join();
        thread2.join();
        thread3.join();

        // Check if the tickets were booked correctly
        assertEquals(97, bookingService.getAvailableSeats("FL789"));
    }
}