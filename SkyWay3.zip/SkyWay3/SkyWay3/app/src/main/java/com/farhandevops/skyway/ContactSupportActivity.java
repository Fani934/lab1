package com.farhandevops.skyway;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ContactSupportActivity extends AppCompatActivity {

    private EditText nameInput, emailInput, subjectInput, messageInput;
    private Button sendButton;
    private TextView promoBanner, customerServiceInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_support);

        // Initialize views
        nameInput = findViewById(R.id.name_input);
        emailInput = findViewById(R.id.email_input);
        subjectInput = findViewById(R.id.subject_input);
        messageInput = findViewById(R.id.message_input);
        sendButton = findViewById(R.id.send_button);
        promoBanner = findViewById(R.id.promo_banner);
        customerServiceInfo = findViewById(R.id.customer_service_info);

        // Set promotional banner text dynamically
        promoBanner.setText("Need Help? Contact Support");

        // Send button click listener
        sendButton.setOnClickListener(v -> {
            String name = nameInput.getText().toString().trim();
            String email = emailInput.getText().toString().trim();
            String subject = subjectInput.getText().toString().trim();
            String message = messageInput.getText().toString().trim();

            if (name.isEmpty() || email.isEmpty() || subject.isEmpty() || message.isEmpty()) {
                Toast.makeText(ContactSupportActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else {
                // Send message functionality (integrate email or contact API here)
                sendSupportMessage(name, email, subject, message);

                // Show confirmation
                Toast.makeText(ContactSupportActivity.this, "Your message has been sent successfully!", Toast.LENGTH_SHORT).show();
                clearForm();
            }
        });
    }

    // Simulate sending the support message (integration with backend needed)
    private void sendSupportMessage(String name, String email, String subject, String message) {
        // For now, just log the message and pretend it's sent
        // You can replace this with actual email functionality or API calls
        // Example: send email via an API like SendGrid or use an Intent to open email client
    }

    // Clear the form after message is sent
    private void clearForm() {
        nameInput.setText("");
        emailInput.setText("");
        subjectInput.setText("");
        messageInput.setText("");
    }
}
