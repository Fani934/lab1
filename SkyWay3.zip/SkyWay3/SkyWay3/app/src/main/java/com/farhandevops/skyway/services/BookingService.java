package com.farhandevops.skyway.services;
import com.farhandevops.skyway.models.Flights;
import com.farhandevops.skyway.models.Ticket;
import com.farhandevops.skyway.models.Customer;
import java.util.*;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
public class BookingService {
    private final List<Ticket<Customer>> bookedTickets; // Synchronized list of tickets (tickets ki synchronized list)
    private final Map<String, Integer> availableSeats; // Har flight ke liye available seats ko track karta hai
    private final Lock bookingLock; // Lock for synchronization (synchronization ke liye lock)
    public BookingService(List<Flights> flights) {
        // Initialize ki gayi list aur map
        this.bookedTickets = Collections.synchronizedList(new ArrayList<>());
        this.availableSeats = new HashMap<>();
        this.bookingLock = new ReentrantLock(); // ReentrantLock ka istemal synchronization ke liye
        // Har flight ke liye available seats ko initialize karna
        for (Flights flight : flights) {
            availableSeats.put(flight.getFlightId(), flight.getTotalSeats());
        }
    }
    // Method to book a ticket (Ticket book karne ka method)
    public Ticket<Customer> bookTicket(String flightId, Customer customer, double price) throws Exception {
        bookingLock.lock(); // Lock acquire karna for synchronization (synchronization ke liye lock lagana)
        try {
            // Check karna agar seats available hain ya nahi
            if (!availableSeats.containsKey(flightId) || availableSeats.get(flightId) <= 0) {
                throw new Exception("No available seats for flight: " + flightId);
            }
            // Ticket ID generate karna
            String ticketId = UUID.randomUUID().toString();
            // Naya ticket create karna
            Ticket<Customer> ticket = new Ticket.Builder<Customer>()
                    .setTicketId(ticketId)
                    .setFlightId(flightId)
                    .setPassengerInfo(customer)
                    .setPrice(price)
                    .build();
            // Available seats ko update karna
            availableSeats.put(flightId, availableSeats.get(flightId) - 1);
            // Booked tickets ki list mein ticket ko add karna
            bookedTickets.add(ticket);

            return ticket;
        } finally {
            bookingLock.unlock(); // Lock ko release karna
        }
    }
    // Method to fetch all booked tickets (Sari booked tickets ko fetch karne ka method)
    public List<Ticket<Customer>> getBookedTickets() {
        return new ArrayList<>(bookedTickets); // List ka ek copy return karna
    }
    // Method to check available seats for a flight (Kisi flight ke liye available seats check karne ka method)
    public int getAvailableSeats(String flightId) throws Exception {
        if (!availableSeats.containsKey(flightId)) {
            throw new Exception("Invalid flight ID: " + flightId);
        }
        return availableSeats.get(flightId); // Available seats return karna
    }
}
