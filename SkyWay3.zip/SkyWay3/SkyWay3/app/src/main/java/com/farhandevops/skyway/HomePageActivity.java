package com.farhandevops.skyway;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class HomePageActivity extends AppCompatActivity {

    private TextView promoBanner, appTitle, welcomeText;
    private ImageView logo;
    private Button btnBookFlight, btnCheckStatus, btnUserProfile, btnLogout, btnContactSupport;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        // Initialize views
        promoBanner = findViewById(R.id.promo_banner);
        appTitle = findViewById(R.id.app_title);
        logo = findViewById(R.id.logo);
        welcomeText = findViewById(R.id.welcome_text);
        btnBookFlight = findViewById(R.id.btn_book_flight);
        btnCheckStatus = findViewById(R.id.btn_check_status);
        btnUserProfile = findViewById(R.id.btn_user_profile);
        btnLogout = findViewById(R.id.btn_logout);
        btnContactSupport = findViewById(R.id.btn_contact_support);

        // Set click listeners
        btnBookFlight.setOnClickListener(v -> {
            Intent intent = new Intent(HomePageActivity.this, BookFlightActivity.class);
            startActivity(intent);
        });

        btnCheckStatus.setOnClickListener(v -> {
            Intent intent = new Intent(HomePageActivity.this, CheckStatusActivity.class);
            startActivity(intent);
        });

        btnUserProfile.setOnClickListener(v -> {
            Intent intent = new Intent(HomePageActivity.this, UserProfileActivity.class);
            startActivity(intent);
        });

        btnLogout.setOnClickListener(v -> {
            // Redirect to Login Page
            Toast.makeText(HomePageActivity.this, "Logging out...", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(HomePageActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // Clear activity stack
            startActivity(intent);
        });

        btnContactSupport.setOnClickListener(v -> {
            Intent intent = new Intent(HomePageActivity.this, ContactSupportActivity.class);
            startActivity(intent);
        });

        // Optional: Dynamic content example
        promoBanner.setText("Fly with Skyway! Exclusive New Year Deals Available!");
        welcomeText.setText("Welcome to Skyway! ✈️ Your journey starts here.");
    }
}
