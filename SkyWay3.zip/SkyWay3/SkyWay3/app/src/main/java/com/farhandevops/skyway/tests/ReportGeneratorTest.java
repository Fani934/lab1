package com.farhandevops.skyway.tests;
import com.farhandevops.skyway.models.Customer;
import com.farhandevops.skyway.models.Flights;
import com.farhandevops.skyway.models.Ticket;
import com.farhandevops.skyway.services.ReportGenerator;

import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ReportGeneratorTest {

    @Test
    public void testGenerateTicketReport() throws IOException {
        List<Ticket<?>> tickets = new ArrayList<>();

        // Create mock data for tickets
        Customer customer = new Customer.Builder()
                .setCustomerId("C001")
                .setName("Bilal Latif")
                .setEmail("bilallatif@example.com")
                .setPhone("1234567890")
                .build();

        tickets.add(new Ticket.Builder<>()
                .setTicketId("T001")
                .setFlightId("FL123")
                .setPassengerInfo(customer)
                .setPrice(299.99)
                .build());

        // Generate ticket report
        ReportGenerator generator = new ReportGenerator();
        generator.generateTicketReport(tickets, "ticket_report.csv");
    }

    @Test
    public void testGenerateFlightReport() throws IOException {
        List<Flights> flights = new ArrayList<>();

        // Create mock data for flights
        flights.add(new Flights.Builder()
                .setFlightId("FL123")
                .setOrigin("New York")
                .setDestination("Los Angeles")
                .setDepartureTime(String.valueOf(LocalDateTime.now().plusHours(3)))
                .setArrivalTime(String.valueOf(LocalDateTime.now().plusHours(6)))
                .setTotalSeats(100)
                .build());

        flights.add(new Flights.Builder()
                .setFlightId("FL456")
                .setOrigin("London")
                .setDestination("Paris")
                .setDepartureTime(String.valueOf(LocalDateTime.now().plusHours(2)))
                .setArrivalTime(String.valueOf(String.valueOf(String.valueOf(LocalDateTime.now().plusHours(4)))))
                .setTotalSeats(50)
                .build());

        // Generate flight report
        ReportGenerator generator = new ReportGenerator();
        generator.generateFlightReport(flights, "flight_report.csv");
    }
}
