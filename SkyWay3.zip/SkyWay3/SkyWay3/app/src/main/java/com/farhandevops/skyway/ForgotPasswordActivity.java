package com.farhandevops.skyway;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

public class ForgotPasswordActivity extends AppCompatActivity {

    private EditText emailField;
    private MaterialButton resetButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        // Initialize UI components
        emailField = findViewById(R.id.emailField);
        resetButton = findViewById(R.id.resetButton);

        resetButton.setOnClickListener(view -> {
            String email = emailField.getText().toString().trim();

            if (email.isEmpty()) {
                Toast.makeText(this, "Please enter your email", Toast.LENGTH_SHORT).show();
            } else {
                showSecurityQuestionDialog(email);
            }
        });
    }

    private void showSecurityQuestionDialog(String email) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirmed, You are not Robot🔴");
        builder.setMessage("What is 2-3+5-3*3?");

        final EditText answerField = new EditText(this);
        builder.setView(answerField);

        builder.setPositiveButton("Submit", (dialog, which) -> {
            String answer = answerField.getText().toString().trim();
            if (answer.equalsIgnoreCase("-5")) { // Replace with your logic
                Intent intent = new Intent(ForgotPasswordActivity.this, ResetPasswordActivity.class);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "Incorrect answer", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }
}
