package com.farhandevops.skyway;

public class EmailRequest {
    private Sender sender;
    private Recipient[] to;
    private String subject;
    private String htmlContent;
    private Attachment[] attachment;

    public void setSender(Sender sender) {
    }

    public void setTo(Recipient[] recipients) {
    }

    public void setSubject(String subject) {
    }

    public void setHtmlContent(String body) {
    }

    public void setAttachment(Attachment[] attachments) {
    }

    // Constructor, Getters, Setters

    public static class Sender {
        private String email;

        public Sender(String email) {
            this.email = email;
        }
    }

    public static class Recipient {
        private String email;

        public Recipient(String email) {
            this.email = email;
        }
    }

    public static class Attachment {
        private String url;
        private String contentType;
        private String name;

        public Attachment(String url, String contentType, String name) {
            this.url = url;
            this.contentType = contentType;
            this.name = name;
        }
    }
}
