package com.farhandevops.skyway;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.POST;

public interface BrevoAPI {

    @POST("v3/smtp/email")
    Call<Void> sendEmail(
            @Header("api-key") String apiKey,  // This ensures the API key is passed as a header
            @Body EmailRequest emailRequest    // This passes the email request body
    );
}
